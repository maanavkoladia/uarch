gui_state_default_create -off -ini

# Globals
gui_set_state_value -category Globals -key recent_databases -value {{gui_open_db -file /misc/scratch/he3837/UARCH/uarch/design/EverythingEverywhereAllAtOnce/tests/Stages/Harish_StageTesting/vcdplus.vpd -design V1} {gui_open_db -file vcdplus.vpd -design V1} {gui_open_db -file vcdplus.vpd} {gui_open_db -file /misc/scratch/he3837/UARCH/uarch/design/EverythingEverywhereAllAtOnce/tests/Stages/vcdplus.vpd -design V1} {gui_open_db -file *.vpd}}
gui_set_state_value -category Globals -key recent_sessions -value {{gui_load_session -ignore_errors -file /misc/scratch/he3837/UARCH/uarch/design/EverythingEverywhereAllAtOnce/tests/Stages/Harish_StageTesting/session.vcdplus.vpd.tcl -ignore_errors} {gui_load_session -ignore_errors -file /misc/scratch/he3837/UARCH/uarch/design/EverythingEverywhereAllAtOnce/tests/Stages/Harish_StageTesting/jacob_save.tcl -ignore_errors} {gui_load_session -ignore_errors -file /misc/scratch/he3837/UARCH/uarch/design/EverythingEverywhereAllAtOnce/tests/Stages/Harish_StageTesting/session.vcdplus.vpd.tcl} {gui_load_session -ignore_errors -file /misc/scratch/he3837/UARCH/uarch/design/EverythingEverywhereAllAtOnce/tests/Stages/session.vcdplus.vpd.tcl} {gui_load_session -ignore_errors -file /misc/scratch/he3837/UARCH/uarch/design/EverythingEverywhereAllAtOnce/tests/Stages/session.vcdplus.vpd.tcl -ignore_errors}}

# Layout
gui_set_state_value -category Layout -key child_console_size_x -value 1919
gui_set_state_value -category Layout -key child_console_size_y -value 175
gui_set_state_value -category Layout -key child_data_coltype -value 171
gui_set_state_value -category Layout -key child_data_colvalue -value 57
gui_set_state_value -category Layout -key child_data_colvariable -value 279
gui_set_state_value -category Layout -key child_data_size_x -value 496
gui_set_state_value -category Layout -key child_data_size_y -value 917
gui_set_state_value -category Layout -key child_hier_col3 -value {-1}
gui_set_state_value -category Layout -key child_hier_colhier -value 335
gui_set_state_value -category Layout -key child_hier_colpd -value 0
gui_set_state_value -category Layout -key child_hier_coltype -value 107
gui_set_state_value -category Layout -key child_hier_size_x -value 431
gui_set_state_value -category Layout -key child_hier_size_y -value 917
gui_set_state_value -category Layout -key child_list_down -value 151
gui_set_state_value -category Layout -key child_list_right -value 443
gui_set_state_value -category Layout -key child_schematic_docknewline -value false
gui_set_state_value -category Layout -key child_schematic_pos_x -value {-2}
gui_set_state_value -category Layout -key child_schematic_pos_y -value {-21}
gui_set_state_value -category Layout -key child_schematic_size_x -value 988
gui_set_state_value -category Layout -key child_schematic_size_y -value 736
gui_set_state_value -category Layout -key child_source_docknewline -value false
gui_set_state_value -category Layout -key child_source_pos_x -value {-2}
gui_set_state_value -category Layout -key child_source_pos_y -value {-21}
gui_set_state_value -category Layout -key child_source_size_x -value 995
gui_set_state_value -category Layout -key child_source_size_y -value 913
gui_set_state_value -category Layout -key child_watch_size_x -value 1919
gui_set_state_value -category Layout -key child_watch_size_y -value 105
gui_set_state_value -category Layout -key child_wave_colname -value 494
gui_set_state_value -category Layout -key child_wave_colvalue -value 168
gui_set_state_value -category Layout -key child_wave_docknewline -value false
gui_set_state_value -category Layout -key child_wave_left -value 666
gui_set_state_value -category Layout -key child_wave_pos_x -value {-2}
gui_set_state_value -category Layout -key child_wave_pos_y -value {-21}
gui_set_state_value -category Layout -key child_wave_right -value 1248
gui_set_state_value -category Layout -key child_wave_size_x -value 1924
gui_set_state_value -category Layout -key child_wave_size_y -value 808
gui_set_state_value -category Layout -key cov_main_pos_x -value 386
gui_set_state_value -category Layout -key cov_main_pos_y -value 139
gui_set_state_value -category Layout -key cov_main_size_x -value 1104
gui_set_state_value -category Layout -key cov_main_size_y -value 847
gui_set_state_value -category Layout -key main_pos_x -value 608
gui_set_state_value -category Layout -key main_pos_y -value 64
gui_set_state_value -category Layout -key main_size_x -value 2527
gui_set_state_value -category Layout -key main_size_y -value 1079
gui_set_state_value -category Layout -key stand_list_child_docknewline -value false
gui_set_state_value -category Layout -key stand_list_child_pos_x -value {-2}
gui_set_state_value -category Layout -key stand_list_child_pos_y -value {-21}
gui_set_state_value -category Layout -key stand_list_child_size_x -value 603
gui_set_state_value -category Layout -key stand_list_child_size_y -value 302
gui_set_state_value -category Layout -key stand_list_top_pos_y -value 101
gui_set_state_value -category Layout -key stand_list_top_size_x -value 1098
gui_set_state_value -category Layout -key stand_list_top_size_y -value 599
gui_set_state_value -category Layout -key stand_wave_child_docknewline -value false
gui_set_state_value -category Layout -key stand_wave_child_pos_x -value {-2}
gui_set_state_value -category Layout -key stand_wave_child_pos_y -value {-21}
gui_set_state_value -category Layout -key stand_wave_child_size_x -value 1924
gui_set_state_value -category Layout -key stand_wave_child_size_y -value 913
gui_set_state_value -category Layout -key stand_wave_top_pos_x -value 0
gui_set_state_value -category Layout -key stand_wave_top_pos_y -value 64
gui_set_state_value -category Layout -key stand_wave_top_size_x -value 1919
gui_set_state_value -category Layout -key stand_wave_top_size_y -value 1079

# list_value_column

# Sim

# Assertion

# Stream

# Data

# TBGUI

# Driver

# Class

# Member

# ObjectBrowser

# UVM

# Local

# Backtrace

# FastSearch

# Exclusion

# SaveSession

# FindDialog
gui_create_state_key -category FindDialog -key m_pMatchCase -value_type bool -value false
gui_create_state_key -category FindDialog -key m_pMatchWord -value_type bool -value false
gui_create_state_key -category FindDialog -key m_pUseCombo -value_type string -value {}
gui_create_state_key -category FindDialog -key m_pWrapAround -value_type bool -value true

# Widget_History
gui_create_state_key -category Widget_History -key Find|m_pFindFrame|m_pFindCombo -value_type string -value {4000 100}
gui_create_state_key -category Widget_History -key TopLevel.1|qt_top_dock|&Edit|FindCombo -value_type string -value {4000 100}
gui_create_state_key -category Widget_History -key TopLevel.2|EkTopVbox|wndWorkspace|qt_workspacechild2|Wave.1|left|filterVBox|controlHBox|unnamed -value_type string -value *num_pfs
gui_create_state_key -category Widget_History -key TopLevel.2|EkTopVbox|wndWorkspace|qt_workspacechild3|Wave.1|left|filterVBox|controlHBox|unnamed -value_type string -value {*data *data_size latches {}}
gui_create_state_key -category Widget_History -key TopLevel.2|qt_top_dock|&Edit|FindCombo -value_type string -value {4000 100}
gui_create_state_key -category Widget_History -key {dlgSimSetup|m_setupTab|tab pages|SimTab|m_VPDCombo} -value_type string -value inter.vpd
gui_create_state_key -category Widget_History -key {dlgSimSetup|m_setupTab|tab pages|SimTab|m_argsCombo} -value_type string -value {{-ucligui }}
gui_create_state_key -category Widget_History -key {dlgSimSetup|m_setupTab|tab pages|SimTab|m_curDirCombo} -value_type string -value {/home/ecelrc/students/he3837/vlsi1/lab3 /home/ecelrc/students/he3837/vlsi1/lab3/rtl}
gui_create_state_key -category Widget_History -key {dlgSimSetup|m_setupTab|tab pages|SimTab|m_exeCombo} -value_type string -value {./simv /home/ecelrc/students/he3837/vlsi1/lab3/rtl/simv}


gui_state_default_create -off
