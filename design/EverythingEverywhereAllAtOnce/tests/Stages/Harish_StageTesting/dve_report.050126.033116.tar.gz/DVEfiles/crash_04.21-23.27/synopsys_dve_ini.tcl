gui_state_default_create -off -ini

# Globals
gui_set_state_value -category Globals -key recent_databases -value {{gui_open_db -file /misc/scratch/je28497/uarch/design/EverythingEverywhereAllAtOnce/tests/Stages/Harish_StageTesting/vcdplus.vpd -design V1} {gui_open_db -file vcdplus.vpd -design V1} {gui_open_db -file vcdplus.vpd} {gui_open_db -file /home/ecelrc/students/je28497/uarch/design/EverythingEverywhereAllAtOnce/tests/Stages/Harish_StageTesting/vcdplus.vpd -design V1} {gui_open_db -file /home/ecelrc/students/je28497/uarch/design/EverythingEverywhereAllAtOnce/tests/Stages/RestOfStages/vcdplus.vpd -design V1}}
gui_set_state_value -category Globals -key recent_sessions -value {{gui_load_session -ignore_errors -file /misc/scratch/je28497/uarch/design/EverythingEverywhereAllAtOnce/tests/Stages/Harish_StageTesting/jacob_save.tcl -ignore_errors} {gui_load_session -ignore_errors -file /home/ecelrc/students/je28497/uarch/design/EverythingEverywhereAllAtOnce/tests/Stages/Harish_StageTesting/jacob_save.tcl -ignore_errors} {gui_load_session -ignore_errors -file /home/ecelrc/students/je28497/uarch/design/EverythingEverywhereAllAtOnce/tests/Stages/Harish_StageTesting/jacob_save.tcl} {gui_load_session -ignore_errors -file /home/ecelrc/students/je28497/uarch/design/EverythingEverywhereAllAtOnce/tests/Stages/Harish_StageTesting/session.vcdplus.vpd.tcl -ignore_errors} {gui_load_session -ignore_errors -file /home/ecelrc/students/je28497/uarch/design/EverythingEverywhereAllAtOnce/tests/Stages/Harish_StageTesting/session.vcdplus.vpd.tcl}}

# Layout
gui_set_state_value -category Layout -key child_console_size_x -value 1515
gui_set_state_value -category Layout -key child_console_size_y -value 173
gui_set_state_value -category Layout -key child_data_coltype -value 171
gui_set_state_value -category Layout -key child_data_colvalue -value 57
gui_set_state_value -category Layout -key child_data_colvariable -value 279
gui_set_state_value -category Layout -key child_data_size_x -value 494
gui_set_state_value -category Layout -key child_data_size_y -value 673
gui_set_state_value -category Layout -key child_driver_docknewline -value true
gui_set_state_value -category Layout -key child_driver_size_x -value 3071
gui_set_state_value -category Layout -key child_driver_size_y -value 176
gui_set_state_value -category Layout -key child_hier_col3 -value {-1}
gui_set_state_value -category Layout -key child_hier_colhier -value 335
gui_set_state_value -category Layout -key child_hier_colpd -value 0
gui_set_state_value -category Layout -key child_hier_coltype -value 107
gui_set_state_value -category Layout -key child_hier_size_x -value 429
gui_set_state_value -category Layout -key child_hier_size_y -value 673
gui_set_state_value -category Layout -key child_schematic_docknewline -value false
gui_set_state_value -category Layout -key child_schematic_pos_x -value {-2}
gui_set_state_value -category Layout -key child_schematic_pos_y -value {-15}
gui_set_state_value -category Layout -key child_schematic_size_x -value 957
gui_set_state_value -category Layout -key child_schematic_size_y -value 510
gui_set_state_value -category Layout -key child_source_docknewline -value false
gui_set_state_value -category Layout -key child_source_pos_x -value {-2}
gui_set_state_value -category Layout -key child_source_pos_y -value {-15}
gui_set_state_value -category Layout -key child_source_size_x -value 595
gui_set_state_value -category Layout -key child_source_size_y -value 668
gui_set_state_value -category Layout -key child_watch_size_x -value 878
gui_set_state_value -category Layout -key child_watch_size_y -value 175
gui_set_state_value -category Layout -key child_wave_colname -value 455
gui_set_state_value -category Layout -key child_wave_colvalue -value 73
gui_set_state_value -category Layout -key child_wave_left -value 532
gui_set_state_value -category Layout -key child_wave_right -value 998
gui_set_state_value -category Layout -key main_pos_x -value 3083
gui_set_state_value -category Layout -key main_pos_y -value 936
gui_set_state_value -category Layout -key main_size_x -value 4599
gui_set_state_value -category Layout -key main_size_y -value 1709
gui_set_state_value -category Layout -key stand_wave_child_docknewline -value false
gui_set_state_value -category Layout -key stand_wave_child_pos_x -value {-2}
gui_set_state_value -category Layout -key stand_wave_child_pos_y -value {-15}
gui_set_state_value -category Layout -key stand_wave_child_size_x -value 1540
gui_set_state_value -category Layout -key stand_wave_child_size_y -value 688
gui_set_state_value -category Layout -key stand_wave_top_pos_x -value 0
gui_set_state_value -category Layout -key stand_wave_top_pos_y -value 23
gui_set_state_value -category Layout -key stand_wave_top_size_x -value 1279
gui_set_state_value -category Layout -key stand_wave_top_size_y -value 671

# list_value_column

# Sim

# Assertion

# Stream

# Data
gui_set_state_value -category Data -key data_show_mode -value list

# TBGUI

# Driver

# Class

# Member

# ObjectBrowser

# UVM

# Local

# Backtrace

# FastSearch

# Exclusion

# SaveSession

# FindDialog
gui_create_state_key -category FindDialog -key m_pMatchCase -value_type bool -value false
gui_create_state_key -category FindDialog -key m_pMatchWord -value_type bool -value false
gui_create_state_key -category FindDialog -key m_pUseCombo -value_type string -value {}
gui_create_state_key -category FindDialog -key m_pWrapAround -value_type bool -value true

# Widget_History
gui_create_state_key -category Widget_History -key Search.1|m_pStringCombo -value_type string -value {LD_MIO ld_mio ld_mio}
gui_create_state_key -category Widget_History -key TopLevel.1|qt_left_dock|DockWnd3|HSPane.1|pages|Hier.1|hbox|textfilter -value_type string -value {*flag *flags *flags_reg *clk}
gui_create_state_key -category Widget_History -key TopLevel.2|EkTopVbox|wndWorkspace|qt_workspacechild2|Wave.1|left|filterVBox|controlHBox|unnamed -value_type string -value {*u_add_op *add_op *add_ *add}
gui_create_state_key -category Widget_History -key TopLevel.2|EkTopVbox|wndWorkspace|qt_workspacechild3|Wave.1|left|filterVBox|controlHBox|unnamed -value_type string -value {*Read *busy *icache *S_}
gui_create_state_key -category Widget_History -key TopLevel.2|EkTopVbox|wndWorkspace|qt_workspacechild4|Wave.1|left|filterVBox|controlHBox|unnamed -value_type string -value *dcache_will_evict
gui_create_state_key -category Widget_History -key {dlgSimSetup|m_setupTab|tab pages|SimTab|m_VPDCombo} -value_type string -value inter.vpd
gui_create_state_key -category Widget_History -key {dlgSimSetup|m_setupTab|tab pages|SimTab|m_argsCombo} -value_type string -value {{-ucligui +v2k} {-ucligui }}
gui_create_state_key -category Widget_History -key {dlgSimSetup|m_setupTab|tab pages|SimTab|m_curDirCombo} -value_type string -value {/home/ecelrc/students/je28497/uArch/pset4 /home/ecelrc/students/je28497/uArch/pset1 /home/ecelrc/students/je28497/vlsi1/lab3 /home/ecelrc/students/je28497/vlsi1/lab3/rtl /home/ecelrc/students/je28497/vlsi1/dram_vlsi}
gui_create_state_key -category Widget_History -key {dlgSimSetup|m_setupTab|tab pages|SimTab|m_exeCombo} -value_type string -value {/home/ecelrc/students/je28497/uArch/pset4/simv /home/ecelrc/students/je28497/uArch/pset1/simv simv ./simv /home/ecelrc/students/je28497/vlsi1/lab3/rtl/simv}

# SearchDialog
gui_create_state_key -category SearchDialog -key MatchCase -value_type bool -value false
gui_create_state_key -category SearchDialog -key MatchWord -value_type bool -value true
gui_create_state_key -category SearchDialog -key SearchMode -value_type string -value Wildcards
gui_create_state_key -category SearchDialog -key UseCombo -value_type bool -value true


gui_state_default_create -off
